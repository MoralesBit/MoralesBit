const simple = require("./simple");
const bollinger = require("./bollinger");

exports.default = { simple, bollinger };
